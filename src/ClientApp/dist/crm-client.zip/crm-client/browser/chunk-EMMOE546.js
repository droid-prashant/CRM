var t=/^\d{10}$/,E="Contact number must be exactly 10 digits.";export{t as a,E as b};
